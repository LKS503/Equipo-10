import { LNBITS_URL, INVOICE_KEY } from "./config.js";

// Productos
const productos = [
  { id: 1, nombre: "Camiseta Niño", precio: 50, img: "images/camisita.webp", cat: "ropa" },
  { id: 2, nombre: "Pelota Infantil", precio: 80, img: "images/OIP.webp", cat: "juguetes" },
  { id: 3, nombre: "Jugo Natural", precio: 40, img: "images/jugon_de_naranjo.webp", cat: "bebidas" },
  { id: 4, nombre: "Galletas Kids", precio: 25, img: "images/galletita.webp", cat: "comida" }
];
// === Elementos DOM ===
const productContainer = document.getElementById("productContainer");
const searchInput = document.getElementById("search");
const thankYouMessage = document.getElementById("thank-you-message"); // Elemento para el mensaje de agradecimiento

// Carrito
let cart = [];
const modalCart = document.getElementById("modal-cart");
const openCart = document.getElementById("open-cart");
const closeCart = document.getElementById("close-cart");
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");

// Factura
const invoiceModal = document.getElementById("invoice-modal");
const invoiceQR = document.getElementById("invoice-qr");
const invoiceBolt = document.getElementById("invoice-bolt");
const invoiceStatus = document.getElementById("invoice-status");
const closeInvoice = document.getElementById("close-invoice");

// === Variables Globales ===
let paymentCheckInterval = null;

// === Funciones Principales ===

// Mostrar productos
function mostrarProductos(lista) {
  productContainer.innerHTML = "";
  lista.forEach(p => {
    productContainer.innerHTML += `
      <div class="item">
        <img src="${p.img}" alt="${p.nombre}">
        <h3>${p.nombre}</h3>
        <p><strong>${p.precio} sats</strong></p>
        <button class="btn" onclick="agregarCarrito(${p.id})">Agregar 🛒</button>
      </div>
    `;
  });
}
mostrarProductos(productos);

// Búsqueda
searchInput.addEventListener("input", () => {
  const t = searchInput.value.toLowerCase();
  mostrarProductos(productos.filter(p => p.nombre.toLowerCase().includes(t)));
});

// Filtros por categoría
document.querySelectorAll(".categories button").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelector(".categories .active")?.classList.remove("active");
    btn.classList.add("active");
    mostrarProductos(btn.dataset.cat === "all" ? productos : productos.filter(p => p.cat === btn.dataset.cat));
  });
});

// --- Carrito con cantidades ---
window.agregarCarrito = id => {
  const item = cart.find(p => p.id === id);
  if (item) {
    item.cantidad++;
  } else {
    const prod = { ...productos.find(p => p.id === id), cantidad: 1 };
    cart.push(prod);
  }
  actualizarCarrito();
};

function actualizarCarrito() {
  cartItems.innerHTML = "";
  let total = 0;

  cart.forEach((item, i) => {
    total += item.precio * item.cantidad;
    cartItems.innerHTML += `
      <div>${item.nombre} - ${item.precio} sats x ${item.cantidad} 
      <button onclick="eliminar(${i})">❌</button></div>
    `;
  });

  cartTotal.textContent = total;
  document.getElementById("cart-count").textContent = cart.reduce((a,b)=>a+b.cantidad,0);
}

window.eliminar = i => {
  cart.splice(i, 1);
  actualizarCarrito();
};

// --- Modales ---
openCart.onclick = () => modalCart.style.display = "flex";
closeCart.onclick = () => modalCart.style.display = "none";

closeInvoice.onclick = () => {
  invoiceModal.style.display = "none";

  if (paymentCheckInterval) {
    clearInterval(paymentCheckInterval);
    paymentCheckInterval = null;
    console.log("Chequeo de pago detenido.");
  }
};

// --- Lógica de Pago ---
document.getElementById("checkout-sats").onclick = async () => {
  if (cart.length === 0) return alert("Carrito vacío");

  const total = cart.reduce((a, b) => a + b.precio * b.cantidad, 0);
  console.log("Total sats a facturar:", total);

  invoiceStatus.textContent = "Generando factura...";
  invoiceQR.style.display = "none";
  invoiceBolt.textContent = "";
  invoiceModal.style.display = "flex";

  if (paymentCheckInterval) {
    clearInterval(paymentCheckInterval);
  }

  const factura = await generarFactura(total);

  const bolt11 = factura?.payment_request || factura?.bolt11 || factura?.invoice;

  if (!bolt11) {
    console.error("LNbits no devolvió un bolt11 válido:", factura);
    invoiceStatus.textContent = "Error generando invoice";
    return;
  }

  const payment_hash = factura?.payment_hash;
  if (!payment_hash) {
    console.error("LNbits no devolvió un payment_hash:", factura);
    invoiceStatus.textContent = "Error obteniendo payment_hash";
    return;
  }

  invoiceQR.src = `https://api.qrserver.com/v1/create-qr-code/?data=${bolt11}&size=250x250`;
  invoiceQR.style.display = "block";
  invoiceBolt.textContent = bolt11;
  invoiceStatus.textContent = "Escanea y paga ⚡";

  // POLLING
  paymentCheckInterval = setInterval(async () => {
    console.log("Verificando pago...");
    const status = await verificarPago(payment_hash);

    if (status.paid) {
      console.log("¡Pago recibido!");
      clearInterval(paymentCheckInterval);
      paymentCheckInterval = null;

      invoiceModal.style.display = "none";
      modalCart.style.display = "none";

      // Mostrar mensaje de agradecimiento
      thankYouMessage.textContent = "¡Gracias por su compra! ⚡";
      thankYouMessage.style.display = "block"; // Hacer visible el mensaje

      // Limpiar el carrito
      cart = [];
      actualizarCarrito();
    } else {
      invoiceStatus.textContent = "Esperando pago... ⚡";
    }
  }, 3000);
};

// Copiar bolt
document.getElementById("copy-bolt").onclick = () => {
  navigator.clipboard.writeText(invoiceBolt.textContent);
  alert("Factura copiada 📋⚡");
};

// --- Funciones API LNbits ---

async function generarFactura(monto) {
  try {
    const res = await fetch(`${LNBITS_URL}/api/v1/payments`, {
      method: "POST",
      headers: {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Api-Key": INVOICE_KEY
      },
      body: JSON.stringify({
        amount: monto,
        memo: "Compra Kids",
        out: false
      })
    });

    const data = await res.json();
    console.log("Respuesta LNbits:", data);
    return data;

  } catch (e) {
    console.error("Error LNbits:", e);
    return null;
  }
}

// Verificar Pago
async function verificarPago(payment_hash) {
  try {
    const res = await fetch(`${LNBITS_URL}/api/v1/payments/${payment_hash}`, {
      method: "GET",
      headers: {
        "accept": "application/json",
        "X-Api-Key": INVOICE_KEY
      }
    });

    const data = await res.json();
    console.log("Estado del pago:", data);

    return { paid: data.paid || false };

  } catch (e) {
    console.error("Error verificando pago:", e);
    return { paid: false };
  }
}
