const LNBITS_URL = 'http://chirilicas.com:5000';
const ADMIN_KEY = '8c59bbba642e490f8bab51d479c04878';
const INVOICE_KEY = 'c001947416644687a00421de1b4a804f';

export { LNBITS_URL, ADMIN_KEY, INVOICE_KEY };
