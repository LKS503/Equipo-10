
export default {
  server: {
    port: 5173,
  }
};
